//
//  AuthMe.h
//  AuthMe
//
//  Created by Mikimoto on 2021/8/21.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//! Project version number for AuthMe.
FOUNDATION_EXPORT double AuthMeVersionNumber;

//! Project version string for AuthMe.
FOUNDATION_EXPORT const unsigned char AuthMeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AuthMe/PublicHeader.h>


