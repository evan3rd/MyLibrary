#pragma once
#ifdef __cplusplus
extern "C" {
#endif

#include "engine_service_type.h"

void AuthMe_ReleaseImage(AuthMeImage* pImage);

long AuthMe_CreateModel(const char* modelName, const char* modelPath);

void AuthMe_ReleaseModel(long model);

void GetFASStageName(EAuthMeFASServiceStage eStage, char* pBuffer, int iSize);

#ifdef __cplusplus
}
#endif